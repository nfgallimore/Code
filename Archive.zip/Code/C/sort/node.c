typdef struct node
{
	int data;
	node* next;
}
node;
