#include <stdio.h>
#include <cs50.h>

int main()
{
// get a non-negative height not greater than 23
do while (height < 0 or height > 23
    get input

// loop through each line
for i = 0; i < input; i++
    loop for space
    loop for hash
    print hash & newline

end
}
