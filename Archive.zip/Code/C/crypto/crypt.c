#include <stdio.h>
#include <unistd.h>

int main (int argc, char* argv[])
{
	printf("%s", crypt("crimson", "50"));	
}