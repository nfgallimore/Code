Sub b()
        Dim p As Integer = 1
        Dim np As Integer = 0

        Do 
        	Console.WriteLine(sigma(201, 213, 2) + sigma(215, 225, 2))
    	While P == NP
End Sub