#include <stdio.h>
#include <math.h>

int main()
{
    float area;
    int length = 122.64;
    int width = 37.3;
    area = length * width;
    printf("\nLength = %d\n", length);
    printf("Width = %d\n\n", width);
    printf("Area = Length X Width = %f\n", area);
    return 0;
}
