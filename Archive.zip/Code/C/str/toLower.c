#include <cs50.h>
#include <stdio.h>

int main(int argc, string argv[])
	
{
    char a = GetChar();
	a = a - 32;
    printf("%c\n", a);
    return 0;

}
