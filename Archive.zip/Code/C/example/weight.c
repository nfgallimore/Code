#include <stdio.h>
#include <cs50.h>

int main()
{
    do
    {
        printf("If you are a male, please type "male". If you are a female, please type "female":\n\n")
        int gender = GetString();
    }
        while (gender != male || female);

    printf("Please enter your height in inches: \n\n");
    int height = GetInt();
    
    while (height < 60)
    {
        printf("This algorithm is like a roller coaster, you must be at least 60 inches to ride.")
        int height = GetInt();
    }
    
    // Okay now lets start processing yada yada snoooooozeeeeeee.
    int LeftOverweight = height - 60;
    
    if (gender == male)
        MaleWeight = (weight * 7 ) + 106;
        
    // we know its a female for sure due to the while loop above, but hey why not check again
    else (gender == female)
        int FemaleWeight = (weight * 6 ) + 100;
        
    printf("\nOkay so you must be a %s, you are %d inches tall. \n 
    printf("That would be %f feet and %d inches but you already knew that. 
    printf("\n According to my sources, you must weigh %d pounds. \n 
    printf("Chances are I'm off by a little, mind telling me how your actual weight?\n")
    actualWeight = GetInt();
    printf("This is what you would should weigh based upon your height.")
    for (int m = 106, m < 1000, i++)
    {
        
        for (int f = 100, f < 1000, f++)
            printf("")
            printf(" \n %d Height:  %d  Weight:  Actual Weight: %d  ", [height][f])
    
        

